import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import type { Prisma } from "@prisma/client";

// Body: { assignmentId, respondentId, projectId, answers: { [targetStudentId]: { [criterionId]: string } } }
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { assignmentId, respondentId, projectId, answers } = body || {} as {
      assignmentId: string;
      respondentId: string;
      projectId: string;
      // answers[targetStudentId][criterionId] = { text: string; rating: number }
      answers: Record<string, Record<string, { text: string; rating: number }>>;
    };

    if (!assignmentId || !respondentId || !projectId || !answers || typeof answers !== 'object') {
      return NextResponse.json({ error: "assignmentId, respondentId, projectId, answers required" }, { status: 400 });
    }

    const assignment = await prisma.surveyAssignment.findFirst({
      where: { id: assignmentId },
      include: { project: true },
    });
    if (!assignment) return NextResponse.json({ error: "Assignment not found" }, { status: 404 });

    // Use the assignment's projectId instead of trusting client-provided one
    const actualProjectId = assignment.projectId;
    
    // Verify the projectId matches (if provided)
    if (projectId && projectId !== actualProjectId) {
      return NextResponse.json({ error: "Project ID mismatch" }, { status: 400 });
    }

    // Deadline check
    if (new Date(assignment.deadline).getTime() < Date.now()) {
      return NextResponse.json({ error: "Deadline has passed" }, { status: 400 });
    }

    // Ensure respondent is part of a team in this project
    const myTeam = await prisma.team.findFirst({
      where: { projectId: actualProjectId, members: { some: { studentId: respondentId } } },
      include: { members: true },
    });
    if (!myTeam) {
      // Check if student is at least invited to the project
      const invite = await prisma.invite.findFirst({
        where: { 
          projectId: actualProjectId, 
          studentId: respondentId,
          status: "accepted"
        },
      });
      
      if (!invite) {
        return NextResponse.json({ error: "You are not assigned to this project. Please accept the project invite first." }, { status: 400 });
      }
      
      return NextResponse.json({ error: "You are not part of a team for this project. Please contact your instructor to be added to a team." }, { status: 400 });
    }

    // Validate targets are in the same team
    const teamMemberIds = new Set(myTeam.members.map((m) => m.studentId));
    for (const targetId of Object.keys(answers)) {
      if (!teamMemberIds.has(targetId)) {
        return NextResponse.json({ error: "Targets must be teammates" }, { status: 400 });
      }
    }

    // Persist one SurveyResponse per target student
    const writes = Object.entries(answers).map(([targetStudentId, answerMap]) =>
      prisma.surveyResponse.upsert({
        where: { assignmentId_respondentId_targetStudentId: { assignmentId, respondentId, targetStudentId } },
        update: { answers: answerMap as Prisma.InputJsonValue },
        create: { assignmentId, respondentId, targetStudentId, answers: answerMap as Prisma.InputJsonValue },
      })
    );
    await Promise.all(writes);

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Error submitting survey response:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}


